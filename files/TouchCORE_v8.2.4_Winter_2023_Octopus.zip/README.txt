TouchCORE v8.2.4_Winter_2023 "Octopus" README
===============================

Built On: February 21 2023
Based On Commit: 84440ada5

